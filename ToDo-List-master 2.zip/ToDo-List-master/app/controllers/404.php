<?php

$title = "Error";
require "/404.view.php";