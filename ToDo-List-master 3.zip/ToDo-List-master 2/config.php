<?php

return [
    "host" => "localhost",
    "dbname" => "auth_bramanis",
    "user" => "root",
    "password" => "root",
    "charset" => "utf8mb4"
];