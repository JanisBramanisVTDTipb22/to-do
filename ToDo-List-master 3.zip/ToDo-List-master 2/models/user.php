<?php
  class User {
    private $db;

    public function __construct(){
      $this->db = new Database;
    }

    // Login User
    public function login($name, $password){
      $this->db->query('SELECT * FROM users WHERE user_name = :username');
      $this->db->bind(':username', $name);

      $row = $this->db->single();

      $hashed_password = $row->password;
      if(password_verify($password, $hashed_password)){
        return $row;
      } else {
        return false;
      }
    }

    // Find user by name
    public function findUserByName($name){
      $this->db->query('SELECT * FROM users WHERE user_name = :username');
      // Bind value
      $this->db->bind(':username', $name);

      $row = $this->db->single();

      // Check row
      if($this->db->rowCount() > 0){
        return true;
      } else {
        return false;
      }
    }
  }