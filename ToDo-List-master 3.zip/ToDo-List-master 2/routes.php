<?php

$routes = [
    "/" => "public/index.php",
];