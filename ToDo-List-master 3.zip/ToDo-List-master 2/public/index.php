<?php 
session_start();

require "../app/core/functions.php";
require "../app/core/router.php";