<?php

$title = "Error";
require "app/views/404.view.php";