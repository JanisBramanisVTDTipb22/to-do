<header>
    <nav>
        <a href="/register">
        <a href="/login">      
    </nav>
</header>