<?php require "components/head.php" ?>
<?php require "components/navbar.php" ?>

<div class="min-h-screen flex flex-col justify-center items-center bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
  <h1 class="text-5xl font-extrabold bg-red-600 py-8 px-12 rounded-lg shadow-lg">Best To Do Program</h1>
</div>

<?php require "components/footer.php" ?>